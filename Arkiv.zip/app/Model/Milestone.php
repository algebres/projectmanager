<?php
	class Milestone extends AppModel {
		public $name = "Milestone";
		public $primaryKey = "milestoneId";
	}
