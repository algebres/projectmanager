<?php
	class Task extends AppModel {
		public $name = "Task";
		public $primaryKey = "taskId";
	}
?>