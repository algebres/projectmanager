<?php
	class Issue extends AppModel {
		public $name = 'Issue';
		public $primaryKey = 'issueId';
	}
?>